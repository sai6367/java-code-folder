import java.util.HashMap;
import java.util.Map;

interface Storage {
    void save(String key, String value);
    String load(String key);
}

class MemoryStorage implements Storage {
    private Map<String, String> data = new HashMap<>();

    public void save(String key, String value) {
        data.put(key, value);
    }

    public String load(String key) {
        return data.get(key);
    }
}

class Q38 {
    public static void main(String[] args) {
        Storage storage = new MemoryStorage();
        storage.save("name", "Sai");
        storage.save("course", "Java");
        System.out.println("Name: " + storage.load("name"));
        System.out.println("Course: " + storage.load("course"));
    }
}
