class Notification {
    void send() { System.out.println("Sending notification."); }
}

class EmailNotification extends Notification {
    @Override
    void send() { System.out.println("Sending email notification."); }
}

class SMSNotification extends Notification {
    @Override
    void send() { System.out.println("Sending SMS notification."); }
}

class Q26 {
    public static void main(String[] args) {
        Notification[] notifications = {
            new EmailNotification(), new SMSNotification()
        };
        for (Notification n : notifications) {
            n.send();
        }
    }
}
