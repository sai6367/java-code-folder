interface Notification {
    void sendReminder(String message);
}

class ConsoleNotification implements Notification {
    public void sendReminder(String message) {
        System.out.println("Console reminder: " + message);
    }
}

class EmailNotification implements Notification {
    public void sendReminder(String message) {
        System.out.println("Email reminder: " + message);
    }
}

class Q35 {
    static void remind(Notification notification, String message) {
        notification.sendReminder(message);
    }

    public static void main(String[] args) {
        remind(new ConsoleNotification(), "Submit the assignment.");
        remind(new EmailNotification(), "Attend the practical exam.");
    }
}
