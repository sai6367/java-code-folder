class User {
    String name;
    User(String name) { this.name = name; }

    void membershipSummary() {
        System.out.println(name + " is a regular member.");
    }
}

class PremiumUser extends User {
    int rewardPoints;

    PremiumUser(String name, int rewardPoints) {
        super(name);
        this.rewardPoints = rewardPoints;
    }

    @Override
    void membershipSummary() {
        System.out.println(name + " is a premium member with "
                + rewardPoints + " reward points.");
    }
}

class Q23 {
    public static void main(String[] args) {
        User u = new PremiumUser("Sai", 500);
        u.membershipSummary();
    }
}
