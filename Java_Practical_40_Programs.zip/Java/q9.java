class Employee {
    private int emp_id;
    private String name, dept;
    private double salary;

    Employee(int emp_id, String name, String dept, double salary) {
        this.emp_id = emp_id;
        this.name = name;
        this.dept = dept;
        this.salary = salary;
    }

    public int getEmp_id() { return emp_id; }
    public String getName() { return name; }
    public String getDept() { return dept; }
    public double getSalary() { return salary; }

    public void setName(String name) { this.name = name; }
    public void setDept(String dept) { this.dept = dept; }
    public void setSalary(double salary) {
        if (salary >= 0) this.salary = salary;
    }
}

class Q9 {
    public static void main(String[] args) {
        Employee e = new Employee(101, "Anil", "IT", 35000);
        System.out.println("ID: " + e.getEmp_id());
        System.out.println("Name: " + e.getName());
        System.out.println("Department: " + e.getDept());
        System.out.println("Salary: " + e.getSalary());
    }
}
