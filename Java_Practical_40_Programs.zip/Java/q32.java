abstract class Shape {
    abstract double area();
    abstract void description();
}

class Circle extends Shape {
    double radius;
    Circle(double radius) { this.radius = radius; }
    double area() { return Math.PI * radius * radius; }
    void description() { System.out.println("Circle area: " + area()); }
}

class Rectangle extends Shape {
    double length, breadth;
    Rectangle(double length, double breadth) {
        this.length = length;
        this.breadth = breadth;
    }
    double area() { return length * breadth; }
    void description() { System.out.println("Rectangle area: " + area()); }
}

class Q32 {
    public static void main(String[] args) {
        Shape[] shapes = { new Circle(3), new Rectangle(4, 5) };
        for (Shape s : shapes) s.description();
    }
}
