interface Payable {
    void printInvoice();
}

abstract class Document {
    String documentName;
    Document(String documentName) { this.documentName = documentName; }
    abstract double total();
}

class Invoice extends Document implements Payable {
    String[] items;
    double[] prices;

    Invoice(String documentName, String[] items, double[] prices) {
        super(documentName);
        this.items = items;
        this.prices = prices;
    }

    double total() {
        double sum = 0;
        for (double price : prices) sum += price;
        return sum;
    }

    public void printInvoice() {
        System.out.println("Invoice: " + documentName);
        for (int i = 0; i < items.length; i++) {
            System.out.println(items[i] + " : " + prices[i]);
        }
        System.out.println("Total: " + total());
    }
}

class Q39 {
    public static void main(String[] args) {
        Invoice invoice = new Invoice("Stationery",
                new String[] {"Pen", "Book", "Pencil"},
                new double[] {10, 50, 5});
        invoice.printInvoice();
    }
}
