import java.util.Scanner;

class BankAccount {
    String holder;
    long accountNumber;
    double balance;

    BankAccount(String holder, long accountNumber, double balance) {
        this.holder = holder;
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposit successful.");
        } else System.out.println("Enter a valid amount.");
    }

    void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawal successful.");
        } else System.out.println("Insufficient balance or invalid amount.");
    }

    void checkBalance() {
        System.out.println("Current balance: " + balance);
    }

    void display() {
        System.out.println("Account holder: " + holder);
        System.out.println("Account number: " + accountNumber);
        checkBalance();
    }
}

class Q3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BankAccount account = new BankAccount("Sai", 123456789L, 5000);
        account.display();
        System.out.print("Enter deposit amount: ");
        account.deposit(sc.nextDouble());
        System.out.print("Enter withdrawal amount: ");
        account.withdraw(sc.nextDouble());
        account.display();
        sc.close();
    }
}
