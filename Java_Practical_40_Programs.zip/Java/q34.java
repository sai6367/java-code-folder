abstract class Employee {
    String name;
    Employee(String name) { this.name = name; }
    abstract double monthlyPay();
}

class SalariedEmployee extends Employee {
    double salary;
    SalariedEmployee(String name, double salary) {
        super(name);
        this.salary = salary;
    }
    double monthlyPay() { return salary; }
}

class HourlyEmployee extends Employee {
    double rate;
    int hours;
    HourlyEmployee(String name, double rate, int hours) {
        super(name);
        this.rate = rate;
        this.hours = hours;
    }
    double monthlyPay() { return rate * hours; }
}

class Q34 {
    public static void main(String[] args) {
        Employee[] employees = {
            new SalariedEmployee("Arun", 35000),
            new HourlyEmployee("Neha", 150, 160)
        };
        for (Employee e : employees) {
            System.out.println(e.name + " monthly pay: " + e.monthlyPay());
        }
    }
}
