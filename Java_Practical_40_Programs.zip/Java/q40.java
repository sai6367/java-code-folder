class Person {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

class Student extends Person {
    int id;
    double score;

    Student(String name, int age, int id, double score) {
        super(name, age);
        this.id = id;
        this.score = score;
    }

    void displayRecord() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Student ID: " + id);
        System.out.println("Score: " + score);
        System.out.println("Status: " + (score >= 40 ? "Pass" : "Fail"));
    }
}

class Q40 {
    public static void main(String[] args) {
        Student s = new Student("Sai", 19, 101, 78);
        s.displayRecord();
    }
}
