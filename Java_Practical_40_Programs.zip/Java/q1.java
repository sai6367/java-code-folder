import java.util.Scanner;

class Student {
    String name;
    int rollNumber, age;
    double marks;

    Student(String name, int rollNumber, int age, double marks) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.age = age;
        this.marks = marks;
    }

    void display() {
        System.out.println("Name: " + name);
        System.out.println("Roll Number: " + rollNumber);
        System.out.println("Age: " + age);
        System.out.println("Marks: " + marks);
    }
}

class Q1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter name: ");
        String name = sc.nextLine();
        System.out.print("Enter roll number: ");
        int roll = sc.nextInt();
        System.out.print("Enter age: ");
        int age = sc.nextInt();
        System.out.print("Enter marks: ");
        double marks = sc.nextDouble();

        Student s = new Student(name, roll, age, marks);
        s.display();
        sc.close();
    }
}
