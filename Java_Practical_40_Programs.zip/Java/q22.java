class Appliance {
    double powerWatts;

    Appliance(double powerWatts) { this.powerWatts = powerWatts; }

    double energyUsed(double hours) {
        return powerWatts * hours / 1000.0;
    }
}

class WashingMachine extends Appliance {
    double capacityKg;

    WashingMachine(double powerWatts, double capacityKg) {
        super(powerWatts);
        this.capacityKg = capacityKg;
    }

    void displayUsage(double hours) {
        System.out.println("Energy used: " + energyUsed(hours) + " kWh");
        System.out.println("Water usage estimate: " + (capacityKg * 10) + " litres");
    }
}

class Q22 {
    public static void main(String[] args) {
        WashingMachine wm = new WashingMachine(500, 7);
        wm.displayUsage(2);
    }
}
