class AreaCalculator {
    double area(double side) { return side * side; }
    double area(double length, double breadth) { return length * breadth; }
    double area(int radius) { return Math.PI * radius * radius; }
}

class Q29 {
    public static void main(String[] args) {
        AreaCalculator a = new AreaCalculator();
        System.out.println("Square area: " + a.area(4.0));
        System.out.println("Rectangle area: " + a.area(5.0, 3.0));
        System.out.println("Circle area: " + a.area(3));
    }
}
