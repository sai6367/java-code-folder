class Shape {
    void displayArea(double area) {
        System.out.println("Area: " + area);
    }
}

class Circle extends Shape {
    void area(double r) { displayArea(Math.PI * r * r); }
}

class Square extends Shape {
    void area(double side) { displayArea(side * side); }
}

class Rectangle extends Shape {
    void area(double length, double breadth) {
        displayArea(length * breadth);
    }
}

class Q10 {
    public static void main(String[] args) {
        new Circle().area(5);
        new Square().area(4);
        new Rectangle().area(6, 3);
    }
}
