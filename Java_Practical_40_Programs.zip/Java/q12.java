class Vehicle {
    String brand;
    void start() { System.out.println("The vehicle is starting"); }
}

class Car extends Vehicle {
    String modelName;
    void accelerate() { System.out.println("The car is accelerating"); }
}

class Q12 {
    public static void main(String[] args) {
        Car car = new Car();
        car.brand = "Toyota";
        car.modelName = "Innova";
        System.out.println("Brand: " + car.brand);
        System.out.println("Model: " + car.modelName);
        car.start();
        car.accelerate();
    }
}
