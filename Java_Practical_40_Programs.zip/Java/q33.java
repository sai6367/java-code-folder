interface Payable {
    void pay(double amount);
}

class CashPayment implements Payable {
    public void pay(double amount) {
        System.out.println("Cash payment received: " + amount);
        System.out.println("Cash receipt generated.");
    }
}

class CardPayment implements Payable {
    public void pay(double amount) {
        System.out.println("Card payment completed: " + amount);
        System.out.println("Card receipt generated.");
    }
}

class Q33 {
    public static void main(String[] args) {
        Payable p1 = new CashPayment();
        Payable p2 = new CardPayment();
        p1.pay(500);
        p2.pay(1200);
    }
}
