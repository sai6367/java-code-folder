class LibraryItem {
    String title;
    int loanLength;

    LibraryItem(String title, int loanLength) {
        this.title = title;
        this.loanLength = loanLength;
    }

    void display() {
        System.out.println(title + " - Loan period: " + loanLength + " days");
    }
}

class Book extends LibraryItem {
    Book(String title) { super(title, 14); }
}

class Magazine extends LibraryItem {
    Magazine(String title) { super(title, 7); }
}

class Q21 {
    public static void main(String[] args) {
        new Book("Java Basics").display();
        new Magazine("Science Monthly").display();
    }
}
