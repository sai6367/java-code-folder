class Book {
    String name;
    int price;

    Book() {
        name = "Java";
        price = 200;
    }

    Book(String n, int p) {
        name = n;
        price = p;
    }

    void display() {
        System.out.println(name + " " + price);
    }
}

class Q4 {
    public static void main(String[] args) {
        Book b1 = new Book();
        Book b2 = new Book("Python", 300);
        b1.display();
        b2.display();
    }
}
