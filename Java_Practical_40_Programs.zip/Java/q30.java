interface Exporter {
    void export();
}

class CSVExporter implements Exporter {
    public void export() { System.out.println("Exporting data as CSV."); }
}

class JSONExporter implements Exporter {
    public void export() { System.out.println("Exporting data as JSON."); }
}

class Q30 {
    public static void main(String[] args) {
        Exporter[] exporters = { new CSVExporter(), new JSONExporter() };
        for (Exporter e : exporters) {
            e.export();
        }
    }
}
