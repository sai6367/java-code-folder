abstract class Account {
    double balance;
    Account(double balance) { this.balance = balance; }
    abstract double monthlyInterest();
}

class SavingsAccount extends Account {
    SavingsAccount(double balance) { super(balance); }
    double monthlyInterest() { return balance * 0.04 / 12; }
}

class FixedDeposit extends Account {
    FixedDeposit(double balance) { super(balance); }
    double monthlyInterest() { return balance * 0.07 / 12; }
}

class Q37 {
    public static void main(String[] args) {
        Account a1 = new SavingsAccount(50000);
        Account a2 = new FixedDeposit(50000);
        System.out.println("Savings monthly interest: " + a1.monthlyInterest());
        System.out.println("Fixed deposit monthly interest: " + a2.monthlyInterest());
    }
}
