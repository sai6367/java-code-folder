class Employee {
    String name;
    double monthlySalary;

    Employee(String name, double monthlySalary) {
        this.name = name;
        this.monthlySalary = monthlySalary;
    }

    double bonus() { return 0; }
}

class Manager extends Employee {
    int teamSize;

    Manager(String name, double salary, int teamSize) {
        super(name, salary);
        this.teamSize = teamSize;
    }

    @Override
    double bonus() { return monthlySalary; }

    void display() {
        System.out.println("Name: " + name);
        System.out.println("Team size: " + teamSize);
        System.out.println("Bonus: " + bonus());
    }
}

class Q20 {
    public static void main(String[] args) {
        Manager m = new Manager("Kiran", 40000, 8);
        m.display();
    }
}
