abstract class Discount {
    abstract double apply(double price);
}

class FixedDiscount extends Discount {
    double amount;
    FixedDiscount(double amount) { this.amount = amount; }
    double apply(double price) { return Math.max(0, price - amount); }
}

class PercentageDiscount extends Discount {
    double percentage;
    PercentageDiscount(double percentage) { this.percentage = percentage; }
    double apply(double price) { return price - price * percentage / 100; }
}

class Q31 {
    public static void main(String[] args) {
        double originalPrice = 1000;
        Discount fixed = new FixedDiscount(100);
        Discount percent = new PercentageDiscount(10);
        System.out.println("After fixed discount: " + fixed.apply(originalPrice));
        System.out.println("After percentage discount: " + percent.apply(originalPrice));
    }
}
