class Payment {
    double processingFee(double amount) { return 0; }
}

class CardPayment extends Payment {
    @Override
    double processingFee(double amount) { return amount * 0.02; }
}

class UpiPayment extends Payment {
    @Override
    double processingFee(double amount) { return amount * 0.005; }
}

class CashPayment extends Payment {
    @Override
    double processingFee(double amount) { return 0; }
}

class Q27 {
    public static void main(String[] args) {
        Payment[] payments = {
            new CardPayment(), new UpiPayment(), new CashPayment()
        };
        double amount = 1000;
        for (Payment p : payments) {
            System.out.println("Processing fee: " + p.processingFee(amount));
        }
    }
}
