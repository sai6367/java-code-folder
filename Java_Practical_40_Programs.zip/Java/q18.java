class Vehicle {
    String brand;
    double mileage;

    Vehicle(String brand, double mileage) {
        this.brand = brand;
        this.mileage = mileage;
    }

    double fuelRequired(double distance) {
        return distance / mileage;
    }
}

class Car extends Vehicle {
    Car(String brand, double mileage) {
        super(brand, mileage);
    }

    void estimateTripFuel(double distance) {
        System.out.println("Vehicle: " + brand);
        System.out.println("Fuel needed for " + distance + " km: "
                + fuelRequired(distance) + " litres");
    }
}

class Q18 {
    public static void main(String[] args) {
        Car car = new Car("Honda", 15);
        car.estimateTripFuel(300);
    }
}
