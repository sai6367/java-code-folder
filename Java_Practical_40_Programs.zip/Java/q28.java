class Worker {
    String name;
    Worker(String name) { this.name = name; }
    double calculatePay() { return 0; }
}

class SalariedWorker extends Worker {
    double monthlySalary;
    SalariedWorker(String name, double salary) {
        super(name);
        monthlySalary = salary;
    }
    @Override
    double calculatePay() { return monthlySalary; }
}

class HourlyWorker extends Worker {
    double hourlyRate;
    int hours;
    HourlyWorker(String name, double rate, int hours) {
        super(name);
        hourlyRate = rate;
        this.hours = hours;
    }
    @Override
    double calculatePay() { return hourlyRate * hours; }
}

class Q28 {
    public static void main(String[] args) {
        Worker[] workers = {
            new SalariedWorker("Ravi", 30000),
            new HourlyWorker("Maya", 200, 120)
        };
        for (Worker w : workers) {
            System.out.println(w.name + " payroll: " + w.calculatePay());
        }
    }
}
