class Employee {
    private int id;
    private String name;
    private double salary;

    public void setId(int id) {
        if (id > 0) this.id = id;
        else System.out.println("Invalid employee ID.");
    }

    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()) this.name = name;
        else System.out.println("Invalid employee name.");
    }

    public void setSalary(double salary) {
        if (salary >= 0) this.salary = salary;
        else System.out.println("Salary cannot be negative.");
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getSalary() { return salary; }
}

class Q5 {
    public static void main(String[] args) {
        Employee e = new Employee();
        e.setId(101);
        e.setName("Ravi");
        e.setSalary(25000);
        System.out.println(e.getId() + " " + e.getName() + " " + e.getSalary());
    }
}
