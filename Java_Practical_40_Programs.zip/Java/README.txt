JAVA PRACTICAL PROGRAMS (Q1-Q40)

Files:
  q1.java ... q40.java

Each file is a separate, standalone Java program. The main class is named Q1, Q2, ...
to match the filename style in the supplied q4.java example.

Run one question in VS Code:
1. Open the Java folder in VS Code.
2. Open the required file, for example q4.java.
3. Make sure the JDK and Java Extension Pack are installed.
4. Click Run above the main() method, or use the terminal:
      javac q4.java
      java Q4

Important:
- Compile/run one question file at a time because several exercises reuse class names
  such as Employee, Animal, Shape, Book, and Payment.
- Questions 18-23 and 26-39 were transcribed from the handwritten question images.
  Where handwriting was unclear, a simple example interpretation was used.
- In Q16, the raise is limited to a maximum of 20%.
- Values such as discount percentages, interest rates, water usage and late-fee rates
  are sample values because the questions do not specify exact rates.
