abstract class LibraryItem {
    int daysLate;
    LibraryItem(int daysLate) { this.daysLate = Math.max(0, daysLate); }
    abstract double lateFee();
}

class Book extends LibraryItem {
    Book(int daysLate) { super(daysLate); }
    double lateFee() { return Math.min(daysLate * 2.0, 100); }
}

class DVD extends LibraryItem {
    DVD(int daysLate) { super(daysLate); }
    double lateFee() { return Math.min(daysLate * 5.0, 200); }
}

class Q36 {
    public static void main(String[] args) {
        LibraryItem book = new Book(12);
        LibraryItem dvd = new DVD(12);
        System.out.println("Book late fee: " + book.lateFee());
        System.out.println("DVD late fee: " + dvd.lateFee());
    }
}
