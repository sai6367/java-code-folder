class Animal {
    void eat() { System.out.println("Animal is eating."); }
    void describe() { System.out.println("This is an animal."); }
}

class Dog extends Animal {
    String breed;

    Dog(String breed) { this.breed = breed; }

    @Override
    void describe() {
        System.out.println("This is a " + breed + " dog.");
    }
}

class Q17 {
    public static void main(String[] args) {
        Dog d = new Dog("Labrador");
        d.eat();
        d.describe();
    }
}
