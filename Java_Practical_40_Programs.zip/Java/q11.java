class Parent {
    void fun() { System.out.println("Parent fun() method."); }
}

class Child extends Parent {
    @Override
    void fun() {
        super.fun();
        System.out.println("Child fun() method.");
    }
}

class Q11 {
    public static void main(String[] args) {
        Child obj = new Child();
        obj.fun();
    }
}
