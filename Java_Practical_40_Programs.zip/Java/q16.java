class Employee {
    private double salary;

    Employee(double salary) {
        this.salary = salary;
    }

    void raiseSalary(double percentage) {
        if (percentage > 0 && percentage <= 20) {
            salary += salary * percentage / 100;
        } else {
            System.out.println("Raise must be between 0 and 20 percent.");
        }
    }

    public double getSalary() { return salary; }
}

class Q16 {
    public static void main(String[] args) {
        Employee e = new Employee(30000);
        e.raiseSalary(20);
        System.out.println("Updated salary: " + e.getSalary());
    }
}
